import sys
sys.path.append("../")
from utils import *
from torch.autograd import Variable

import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import torch.utils.data

import numpy as np
import torch


train_dict = load_train_csv('../data')

def load_data(base_path="../data"):
    """ Load the data in PyTorch Tensor.

    :return: (zero_train_matrix, train_data, valid_data, test_data)
        WHERE:
        zero_train_matrix: 2D sparse matrix where missing entries are
        filled with 0.
        train_data: 2D sparse matrix
        valid_data: A dictionary {user_id: list,
        user_id: list, is_correct: list}
        test_data: A dictionary {user_id: list,
        user_id: list, is_correct: list}
    """
    train_matrix = load_train_sparse(base_path).toarray()
    valid_data = load_valid_csv(base_path)
    test_data = load_public_test_csv(base_path)

    zero_train_matrix = train_matrix.copy()
    # Fill in the missing entries to 0.
    zero_train_matrix[np.isnan(train_matrix)] = 0
    # Change to Float Tensor for PyTorch.
    zero_train_matrix = torch.FloatTensor(zero_train_matrix)
    train_matrix = torch.FloatTensor(train_matrix)

    return zero_train_matrix, train_matrix, valid_data, test_data


class AutoEncoder(nn.Module):
    def __init__(self, num_question, k=100):
        """ Initialize a class AutoEncoder.

        :param num_question: int
        :param k: int
        """
        super(AutoEncoder, self).__init__()

        # Define linear functions.
        self.d1 = nn.Linear(num_question, 200)

        self.g = nn.Linear(200, 10)
        self.h = nn.Linear(10, 200)
        
        # self.g2 = nn.Linear(10, 5)
        # self.h2 = nn.Linear(5, 10)
        
        # self.g3 = nn.Linear(10, 1)
        # self.h3 = nn.Linear(1, 10)

        self.d2 = nn.Linear(200, num_question)

    def get_weight_norm(self):
        """ Return ||W^1|| + ||W^2||.

        :return: float
        """
        g_w_norm = torch.norm(self.d1.weight, 1)
        h_w_norm = torch.norm(self.d2.weight, 1)
        return g_w_norm + h_w_norm + torch.norm(self.d1.weight, 1) + torch.norm(self.d2.weight, 1)

    def forward(self, inputs):
        """ Return a forward pass given inputs.

        :param inputs: user vector.
        :return: user vector.
        """
        #####################################################################
        # TODO:                                                             #
        # Implement the function as described in the docstring.             #
        # Use sigmoid activations for f and g.                              #
        #####################################################################
        out = F.sigmoid(self.d1(inputs))
        out = F.dropout(out, 0.5)
        out = F.sigmoid(self.g(out))
        out = F.sigmoid(self.h(out))
        out = F.dropout(out, 0.5)
        # out = F.dropout(out, 0.1)
        # out1 = F.sigmoid(self.g1(out))
        # out1 = F.sigmoid(self.h1(out1))
        # out1 = F.dropout(out1, 0.1)

        # out2 = F.sigmoid(self.g2(out))
        # out2 = F.sigmoid(self.h2(out2))
        # out2 = F.dropout(out2, 0.1)

        # out3 = F.sigmoid(self.g3(out))
        # out3 = F.sigmoid(self.h3(out3))
        # out3 = F.dropout(out3, 0.1)

        # out = (out1+out2+out3) / 3
        # out = F.dropout(out, 0.1)
        out = F.sigmoid(self.d2(out))
        #####################################################################
        #                       END OF YOUR CODE                            #
        #####################################################################
        return out


def train(model, lr, lamb, train_data, zero_train_data, valid_data, num_epoch):
    """ Train the neural network, where the objective also includes
    a regularizer.

    :param model: Module
    :param lr: float
    :param lamb: float
    :param train_data: 2D FloatTensor
    :param zero_train_data: 2D FloatTensor
    :param valid_data: Dict
    :param num_epoch: int
    :return: None
    """
    # TODO: Add a regularizer to the cost function. 
    
    # Tell PyTorch you are training the model.
    model.train()

    # Define optimizers and loss function.
    optimizer = optim.Adam(model.parameters(), lr=lr)
    num_student = train_data.shape[0]

    for epoch in range(0, num_epoch):
        train_loss = 0.
        # train_acc = []
        for user_id in range(num_student):
            inputs = Variable(zero_train_data[user_id]).unsqueeze(0)
            target = inputs.clone()

            optimizer.zero_grad()
            output = model(inputs)

            # Mask the target to only compute the gradient of valid entries.
            nan_mask = np.isnan(train_data[user_id].unsqueeze(0).numpy())
            target[0][nan_mask] = output[0][nan_mask]

            loss = torch.sum((output - target) ** 2.) + model.get_weight_norm() * lamb
            loss.backward()

            # output = output + 0.5
            # output.type(torch.IntTensor)
            # train_acc.append(torch.sum((output != target)))
            train_loss += loss.item()
            optimizer.step()

        valid_acc = evaluate(model, zero_train_data, valid_data)
        # train_acc = evaluate_train(model, zero_train_data)
        print("Epoch: {} \tTraining Cost: {:.6f}\t "
              "Valid Acc: {}".format(epoch, train_loss, valid_acc))
        # print("Train Acc: {}".format(train_acc))
    #####################################################################
    #                       END OF YOUR CODE                            #
    #####################################################################


def evaluate(model, train_data, valid_data):
    """ Evaluate the valid_data on the current model.

    :param model: Module
    :param train_data: 2D FloatTensor
    :param valid_data: A dictionary {user_id: list,
    question_id: list, is_correct: list}
    :return: float
    """
    # Tell PyTorch you are evaluating the model.
    model.eval()

    total = 0
    correct = 0

    for i, u in enumerate(valid_data["user_id"]):
        inputs = Variable(train_data[u]).unsqueeze(0)
        output = model(inputs)

        guess = output[0][valid_data["question_id"][i]].item() >= 0.5
        if guess == valid_data["is_correct"][i]:
            correct += 1
        total += 1
    return correct / float(total)


def evaluate_train(model, train_data):
    model.eval()

    total = 0
    correct = 0

    for i, u in enumerate(train_dict["user_id"]):
        inputs = Variable(train_data[u]).unsqueeze(0)
        output = model(inputs)

        guess = output[0][train_dict["question_id"][i]].item() >= 0.5
        if guess == train_dict["is_correct"][i]:
            correct += 1
        total += 1
    return correct / float(total)



def main():
    zero_train_matrix, train_matrix, valid_data, test_data = load_data()

    #####################################################################
    # TODO:                                                             #
    # Try out 5 different k and select the best k using the             #
    # validation set.                                                   #
    #####################################################################
    # Set model hyperparameters.
    k = 10
    N, M = train_matrix.shape
    model = AutoEncoder(M, k)

    # Set optimization hyperparameters.
    lr = 0.001
    num_epoch = 250
    lamb = 0.000

    train(model, lr, lamb, train_matrix, zero_train_matrix,
          valid_data, num_epoch)
    #####################################################################
    #                       END OF YOUR CODE                            #
    #####################################################################


if __name__ == "__main__":
    main()
